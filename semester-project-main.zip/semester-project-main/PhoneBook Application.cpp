#include<iostream>
#include<fstream>
#include<string> // Include the string header for getline function
using namespace std;

class PhoneBook 
{
    
    char n[28];
    char m[17];
    char e[40];
    char g[30];
    public:
    void storeData() // Changed return type to void
    {
        cout<<"\n.......CREATE NEW PHONE RECORD.........\n";
        cout<<"Enter Record Name   : ";
        cin.ignore(); // Remove cin here, since getline() is used below
        cin.getline(n,28);
        cout<<"Enter Mobile Number : ";
        cin.getline(m,17);
        cout<<"Enter E-Mail I. D.  : ";
        cin.getline(e,40);
        cout<<"Enter Record Group  : ";
        cin.getline(g,30);
        cout<<endl;
    }
    void showData() // Changed return type to void
    {
        cout<<"\n...............PHONE BOOK RECORD...............\n";
        cout<<"Name       : "<<n<<endl;
        cout<<"Mobile No. : "<<m<<endl;
        cout<<"Email ID   : "<<e<<endl;
        cout<<"Group      : "<<g<<endl;
    }
};

void NumberSum()
{
    ofstream fout;
    fout.open("PhoneBook.dat",ios::out|ios::binary|ios::app);
    PhoneBook x; // Create a new object
    x.storeData(); // Call storeData() on the new object
    fout.write((char*)&x,sizeof(x));
    fout.close();
    cout<<"\nRecord Saved to File......\n";
}

void Show_Records()
{
    ifstream fin;
    fin.open("PhoneBook.dat",ios::in|ios::binary); // Change ios::out to ios::in
    PhoneBook x; // Create a new object
    while(fin.read((char*)&x,sizeof(x)))
    {
        x.showData();
    }
    fin.close();
    cout<<"\nReading of Data File Completed......\n";
}

// Implement the other functions similarly

void menu()
{
    int ch;
    do
    {
        cout<<"............................................\n";
        cout<<"           PHONE BOOK MANAGEMENT\n";
        cout<<"............................................\n\n";
        cout<<"::::::::::::::: PROGRAM  MENU :::::::::::::::\n";
        cout<<"0. Exit\n";
        cout<<"1. Save New Phone Record\n";
        cout<<"2. Display All Saved Records\n";
        cout<<"3. Search Specific Record\n";
        cout<<"4. Delete Specific Record\n";
        cout<<"5. Modify Existing Record\n";
        cout<<"Enter Your Choice: ";
        cin>>ch;
        switch(ch)
        {
            case 1: NumberSum(); break;
            case 2: Show_Records(); break;
            // Implement the other cases
        }
    }
    while(ch != 0);
}

int main()
{
    menu();
    return 0;

}